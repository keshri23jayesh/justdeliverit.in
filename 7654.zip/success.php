<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>justdeliverit.in</title>
    <meta name="Jayesh" content="justdeliverit">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="images/favicon.png" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fonts.css">
    <link href="https://fonts.googleapis.com/css?family=Arvo|Josefin+Sans|Lobster|Quicksand:300" rel="stylesheet"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
.button5 {
    background-color: #00bfff;
    border-radius: 25px;
    padding:5px 0px 5px 0px;
}

.button5:hover {
    background-color: #262626;
    border-radius: 25px;
   -webkit-transition-duration: 0.8s; /* Safari */
    transition-duration: 0.8s;
}
</style>
</head>



<body>
<div class="container-fluid">
    <div class="row">
       <center>
          <div class="col-md-4">
          </div>
          <div class="col-md-4">
          <h2> thanks for registering</h2>
          <img src="Dire.png" height="200px" width="200px">  
          <h2>Your Order has been Placed,Wait for our confirmation Call</h2>
          </div>
          <div class="col-md-4">
          </div>
           </center>
       </div>
         <br>
       <div class="row">
         <div class="col-md-4">
         </div>
         <div class="col-md-4">
           <center>
            <a href="http://justdeliverit.in/">
            <div class="button5"><p class="font3" >Place more orders</p></div>
            </a>
            </center>
           </div>
         <div class="col-md-4"></div>
       </div>
    
</div>

</body>


</html>