<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
 
<body>
<div class="container">
    <div class="row">
    <h2><b>Registration</b></h2>

<br>
    </div>
    <div class="row">
    <table class="table table-striped table-bordered table-hover">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>mobile</th>
        <th>email</th>
        <th>address</th>
        <th>landmark</th>
        <th>prodis</th>
        <th>protype</th>
        <th>time</th>
        <th>date</th>
        
       


    </tr>
    <tbody>
    <?php
    include 'dp.php';
    $sql = 'SELECT * FROM info ORDER BY ID DESC';
    foreach ($PDO->query($sql) as $row) {
        echo '<tr>';
        echo '<td>DIV'. $row['id'] . '</td>';
        echo '<td><b style="color:#009933">'. $row['name'] . '</b> </td>';
        echo '<td>'. $row['mobile'] . '</td>';
        echo '<td>'. $row['email'] . '</td>';
        echo '<td>'. $row['address'] . '</td>';
        echo '<td>'. $row['landmark'] . '</td>';
        echo '<td>'. $row['prodis'] . '</td>';
        echo '<td>'. $row['protype'] . '</td>';
        echo '<td>'. $row['time'] . '</td>';
        echo '<td>'. $row['date'] . '</td>';
        
        echo '</tr>';
    }
$PDO = null;
    ?>
    </tbody>
    </table>
    </div><!-- /row -->
</div><!-- /container -->
</body>
</html>