<?php
    $host      = 'localhost';
    $user      = 'justixcl_jay';
    $pass      = 'jay@123';
    $dbname    = 'justixcl_jayesh';
    try 
    {
        $PDO =  new PDO( "mysql:host=".$host.";"."dbname=".$dbname, $user, $pass);  
    }
    catch(PDOException $e) 
    {
        die($e->getMessage());  
    }
?>