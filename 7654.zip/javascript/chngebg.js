
$(function() {
   $(window).scroll(function () {
      if ($(this).scrollTop() > 10) {
         $(�#container-fluid�).addClass(�changeColor�)
      }
      if ($(this).scrollTop() < 10) {
         $(�#container-fluid�).removeClass(�changeColor�)
      }
   });
});