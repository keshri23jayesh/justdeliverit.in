{
   "result": [
      {
         "id": "1",
         "username": "belal",
         "password": "1234"
      },
      {
         "id": "9",
         "username": "faiz",
         "password": "1234"
      },
      {
         "id": "3",
         "username": "sunny",
         "password": "asdf"
      },
      {
         "id": "8",
         "username": "ramiz",
         "password": "1234"
      }
   ]
}