<?php 

define('DB_HOST', 'localhost'); 
define('DB_NAME', 'justixcl_sample');
 define('DB_USER','justixcl_appdev');
 define('DB_PASSWORD','v8fEXuL39kT-$'); 

 $con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die('Unable to Connect jayesh');

  
 