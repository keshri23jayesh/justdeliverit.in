<html lang="en-US" xmlns:og="http://ogp.me/ns#" xmlns:fb="http://ogp.me/ns/fb#" class=" yes-js js_active js js_active  vc_desktop  vc_transform  vc_transform ">
<!--<![endif]-->

<head>
    <meta charset="UTF-8">
    <title>justdeliverit.in</title>
    <meta name="Jayesh" content="justdeliverit.com">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/api2/r20170329125654/recaptcha__en.js"></script>
    <script async="" src="https://www.google-analytics.com/analytics.js"></script>
    <script type="text/javascript">
    document.documentElement.className = document.documentElement.className + ' yes-js js_active js'
    </script>
    
    
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="http://codex-themes.com/thegem/xmlrpc.php">
    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/api2/r20170315121834/recaptcha__en.js"></script>
        <link rel="icon" type="image/png" href="images/favicon.png" />
   
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    
    
     
   
    <style>
    .wishlist_table .add_to_cart,
    a.add_to_wishlist.button.alt {
        border-radius: 16px;
        -moz-border-radius: 16px;
        -webkit-border-radius: 16px
    }
    </style>
    <script type="text/javascript">
    var yith_wcwl_plugin_ajax_web_url = '/thegem/wp-admin/admin-ajax.php';
    </script>
       <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="alternate" hreflang="en-US" href="http://codex-themes.com/thegem/real-estate/">
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link rel="dns-prefetch" href="//s.w.org">
    <link rel="alternate" type="application/rss+xml" title="TheGem » Feed" href="http://codex-themes.com/thegem/feed/">
    <link rel="alternate" type="application/rss+xml" title="TheGem » Comments Feed" href="http://codex-themes.com/thegem/comments/feed/">
    <link rel="stylesheet" id="thegem-preloader-group-css" href="http://codex-themes.com/thegem/wp-content/plugins/bwp-minify/cache/fbaf67fc2355c132f9fd6f570f93c8e18978e070/minify-b1-thegem-preloader-8388a836b859e8ed4dabb6f9896538c2.css" type="text/css" media="all">
    <style id="thegem-reset-inline-css" type="text/css">
    .fullwidth-block {
        -webkit-transform: translate3d(0, 0, 0);
        -moz-transform: translate3d(0, 0, 0);
        -ms-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0)
    }
    </style>
    <link rel="stylesheet" id="thegem-google-fonts-css" href="//fonts.googleapis.com/css?family=Source+Sans+Pro%3Aregular%2C300%7CMontserrat%3A700%2Cregular&amp;subset=vietnamese%2Clatin-ext%2Clatin&amp;ver=4.6.1" type="text/css" media="all">
    <!--[if lt IE 9]><script type='text/javascript' src='http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/themes/thegem/js/html5.js?ver=3.7.3'></script><![endif]-->
    <link rel="https://api.w.org/" href="http://codex-themes.com/thegem/wp-json/">
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://codex-themes.com/thegem/xmlrpc.php?rsd">
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-includes/wlwmanifest.xml">
    <meta name="generator" content="WordPress 4.6.1">
    <meta name="generator" content="WooCommerce 2.6.8">
    <link rel="canonical" href="http://codex-themes.com/thegem/real-estate/">
    <link rel="shortlink" href="http://codex-themes.com/thegem/?p=17430">
    <link rel="alternate" type="application/json+oembed" href="http://codex-themes.com/thegem/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fcodex-themes.com%2Fthegem%2Freal-estate%2F">
    <link rel="alternate" type="text/xml+oembed" href="http://codex-themes.com/thegem/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fcodex-themes.com%2Fthegem%2Freal-estate%2F&amp;format=xml">
   
    <style type="text/css">
    .recentcomments a {
        display: inline!important;
        padding: 0!important;
        margin: 0!important
    }
    </style>
    <meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress.">
    <!--[if lte IE 9]><link
rel="stylesheet" type="text/css" href="http://codex-themes.com/thegem/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]-->
    <!--[if IE  8]><link
rel="stylesheet" type="text/css" href="http://codex-themes.com/thegem/wp-content/plugins/js_composer/assets/css/vc-ie8.min.css" media="screen"><![endif]-->
    <link rel="icon" href="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/uploads/2016/10/cropped-favicon-32x32.png" sizes="32x32">
    <link rel="icon" href="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/uploads/2016/10/cropped-favicon-192x192.png" sizes="192x192">
    <link rel="apple-touch-icon-precomposed" href="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/uploads/2016/10/cropped-favicon-180x180.png">
    <meta name="msapplication-TileImage" content="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/uploads/2016/10/cropped-favicon-270x270.png">
    <style type="text/css" data-type="vc_custom-css">

    // inserting css
       h1, h2, h3, h4, h5, h6 {
    font-family: "Segoe UI",Arial,sans-serif;
    font-weight: 400;
    margin: 10px 0;
}
h1 {
    font-size: 36px;
}
.h1, .h2, .h3, h1, h2, h3 {
    margin-top: 20px;
    margin-bottom: 10px;
}
.h1, .h2, .h3, .h4, .h5, .h6, h1, h2, h3, h4, h5, h6 {
    font-family: inherit;
    font-weight: 500;
    line-height: 1.1;
    color: #333;
    }
    a.socialIcon:hover,
    .socialHoverClass {
        color: #44BCDD;
        background-color: #1a8cff;
        transition-duration: 1s;
    }
    
    .nav>li>a:hover {
        background-color: #1a8cff;
        transition-duration: 1s;
    }
    
    .social-circle li a {
        display: inline-block;
        position: relative;
        margin: 0 auto 0 auto;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        border-radius: 50%;
        text-align: center;
        width: 50px;
        height: 50px;
        font-size: 20px;
    }
    
    .social-circle li i {
        margin: 0;
        line-height: 50px;
        text-align: center;
    }
    
    .social-circle li a:hover i,
    .triggeredHover {
        -moz-transform: rotate(360deg);
        -webkit-transform: rotate(360deg);
        -ms--transform: rotate(360deg);
        transform: rotate(360deg);
        -webkit-transition: all 0.2s;
        -moz-transition: all 0.2s;
        -o-transition: all 0.2s;
        -ms-transition: all 0.2s;
        transition: all 0.2s;
    }
    
    .button1 {
        background-color: transparent;
        color: black;
        border: 3px solid #4CAF50;
        padding: 16px 32px;
        margin-top: 4px;
    }
    
    .button1:hover {
        color: white;
        background-color: #1a8cff;
        transition-duration: 1s;
    }
    
    .jayesh {
        background-color: #1a8cff;
    }
    

      .chota li a {
        display: inline-block;
        position: relative;
        margin: 0 auto 0 auto;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        border-radius: 50%;
        text-align: center;
        width: 25px;
        height: 25px;
        font-size: 13px;
    }
    
    .chota li i {
        margin: 0;
        line-height: 25px;
        text-align: center;
    }
    
    .chota li a:hover i,
    .triggeredHover {
        -moz-transform: rotate(360deg);
        -webkit-transform: rotate(360deg);
        -ms--transform: rotate(360deg);
        transform: rotate(360deg);
        -webkit-transition: all 0.2s;
        -moz-transition: all 0.2s;
        -o-transition: all 0.2s;
        -ms-transition: all 0.2s;
        transition: all 0.2s;
    }

    
    .chota i {
        color: #696969;
        -webkit-transition: all 0.8s;
        -moz-transition: all 0.8s;
        -o-transition: all 0.8s;
        -ms-transition: all 0.8s;
        transition: all 0.8s;
    }
    
    .abtbox {
        margin: 0;
        border-bottom: 8px solid #1aa3ff;
        border-right: 1px solid #e0ebeb;
        border-left: 1px solid #e0ebeb;
        border-top: 1px solid #e0ebeb;
        padding: 20px;
    }
    
    .space {
        margin-bottom;
        20px;
        margin-top: 20px;
    }
    
    .carousel-inner > .item > img,
    .carousel-inner > .item > a > img {
        width: 70%;
        margin: auto;
    }
    
    .contactus {
        background-image: url("http://hdwpro.com/wp-content/uploads/2017/01/HD-City-Building.jpg");
        background-repeat: no-repeat;
        background-size: cover;
        box-shadow: inset 0 0 0 450px rgba(20, 20, 31, 0.9);
        background-position: center;
        min-height: 400px;
    }
    
    p {
        color: #fff;
    }
    /*=========================
  Icons
 ================= */
    /* footer social icons */
    
    ul.social-network {
        list-style: none;
        display: inline;
        margin-left: 0 !important;
        padding: 0;
    }
    
    ul.social-network li {
        display: inline;
        margin: 0 5px;
    }
    /* footer social icons */
    
    .social-network a.icoYouTube:hover {
        background-color: #BB0000;
    }
    
    .social-network a.icoFacebook:hover {
        background-color: #3B5998;
    }
    
    .social-network a.icoTwitter:hover {
        background-color: #33ccff;
    }
    
    .social-network a.icoGoogle:hover {
        background-color: #BD3518;
    }
    
    .social-network a.icoVimeo:hover {
        background-color: #0590B8;
    }
    
    .social-network a.icoLinkedin:hover {
        background-color: #007bb7;
    }
    
    .social-network a.icoInstagram:hover {
        background-color: #125688;
    }
    
    .social-network a.icoSkype:hover {
        background-color: #12A5F4;
    }
    
    .social-network a.icoEnvelope:hover {
        background-color: #22263D;
    }
    
    .social-network a.icoYouTube:hover i,
    .social-network a.icoFacebook:hover i,
    .social-network a.icoTwitter:hover i,
    .social-network a.icoGoogle:hover i,
    .social-network a.icoVimeo:hover i,
    .social-network a.icoLinkedin:hover i,
    .social-network a.icoInstagram:hover i,
    .social-network a.icoSkype:hover i,
    .social-network a.icoEnvelope:hover i {
        color: #fff;
    }
    
    a.socialIcon:hover,
    .socialHoverClass {
        color: #44BCDD;
    }
    
    .social-circle li a {
        display: inline-block;
        position: relative;
        margin: 0 auto 0 auto;
        -moz-border-radius: 50%;
        -webkit-border-radius: 50%;
        border-radius: 50%;
        text-align: center;
        width: 50px;
        height: 50px;
        font-size: 20px;
    }
    
    .social-circle li i {
        margin: 0;
        line-height: 50px;
        text-align: center;
    }
    
    .social-circle li a:hover i,
    .triggeredHover {
        -moz-transform: rotate(360deg);
        -webkit-transform: rotate(360deg);
        -ms--transform: rotate(360deg);
        transform: rotate(360deg);
        -webkit-transition: all 0.2s;
        -moz-transition: all 0.2s;
        -o-transition: all 0.2s;
        -ms-transition: all 0.2s;
        transition: all 0.2s;
    }
    
    .social-circle i {
        color: #696969;
        -webkit-transition: all 0.8s;
        -moz-transition: all 0.8s;
        -o-transition: all 0.8s;
        -ms-transition: all 0.8s;
        transition: all 0.8s;
    }
    
    .beti {
        background-color: #979797;
    }
     .button1 {
        background-color: #00ccff;
        color: white;
        border-radius: 35%;
        padding: 16px 32px;
        margin-top: 4px;
    }
    
    .button1:hover {
        color: #00ccff;
        background-color: white;
        transition-duration: 1s;
    }
   

    
    
    .jayesh {
        background-color: #1a8cff;
    }
    
    .responsive-image {
        background-image: url("bus.jpg");
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
        background-position: center;
         min-height: 700px;
    }
    
    //inserting
    .custom-border {
        border: #fff solid 5px;
        outline: #00bcd4 solid 15px
    }
    
    .block-content {
        background-color: #f0f3f2
    }
    
    .team-person.default-background {
        background-color: #fff!important
    }
    
    .vc_pagination.vc_pagination-style-thegem.vc_pagination-shape-circle .vc_active .vc_pagination-trigger {
        background-color: #46485c
    }
    
    .vc_pagination.vc_pagination-style-thegem.vc_pagination-shape-circle .vc_pagination-trigger {
        background-color: #fff
    }
    
    .vc_tta-tabs.vc_tta-has-pagination .vc_pagination {
        margin-top: -30px;
        z-index: 999
    }
    
    .mc4wp-form-fields p:first-child {
        display: none
    }
    
    .mc4wp-form-fields p,
    .mc4wp-form-fields span {
        color: #fff
    }
    
    .contact-form-style-3 input[type="text"],
    .contact-form-style-3 input[type="email"],
    .contact-form-style-3 textarea {
        color: #99a9b5!important
    }
    
    .contact-form-style-3 input::-webkit-input-placeholder {
        color: #99a9b5!important
    }
    
    .contact-form-style-3 input::-moz-placeholder {
        color: #fff!important
    }
    
    .contact-form-style-3 input:-moz-placeholder {
        color: #fff!important
    }
    
    .contact-form-style-3 input:-ms-input-placeholder {
        color: #99a9b5!important
    }
    
    .contact-form-style-3 textarea::-webkit-input-placeholder {
        color: #99a9b5!important
    }
    
    .contact-form-style-3 textarea::-moz-placeholder {
        color: #fff!important
    }
    
    .contact-form-style-3 textarea:-moz-placeholder {
        color: #fff!important
    }
    
    .contact-form-style-3 textarea:-ms-input-placeholder {
        color: #99a9b5!important
    }
    
    .wpcf7-form .phone:after,
    .wpcf7-form .website:after,
    .wpcf7-form .email:after,
    .wpcf7-form .name:after {
        color: #99a9b5!important
    }
    
    @media(max-width:1199px) {
        .wpb_row {
            margin-top: 0
        }
        body .vc_custom_1459352965013,
        body .vc_custom_1459353150311,
        body .vc_custom_1459352753638 {
            padding-left: 21px!important;
            padding-right: 21px!important
        }
    }
    
    .gem-testimonials.size-medium .gem-testimonial-image {
        border: 4px solid #f0f3f2;
        border-radius: 50%
    }
    
    @media(max-width:1200px) {
        .wpcf7 .cf-style3-website span,
        .wpcf7 .cf-style3-name span,
        .wpcf7 .cf-style3-email span,
        .wpcf7-form .contact-form-style-1 .combobox-wrapper,
        .wpcf7 .cf-style1-website span,
        .wpcf7 .cf-style1-name span,
        .wpcf7 .cf-style1-email span {
            width: 100%!important;
            max-width: 100%!important
        }
        .wpcf7 .cf-style3-textarea span,
        .wpcf7 .cf-style3-textarea textarea {
            width: 100%!important;
            max-height: 100px!important
        }
    }
    </style>
    <style type="text/css" data-type="vc_shortcodes-custom-css">
    .vc_custom_1459345449618 {
        margin-bottom: 0!important
    }
    
    .vc_custom_1459341403798 {
        margin-bottom: 0!important;
        background-color: #f0f3f2!important
    }
    
    .vc_custom_1459342105588 {
        margin-bottom: 0!important;
        background-color: #f0f3f2!important
    }
    
    .vc_custom_1461676756008 {
        margin-bottom: -22px!important
    }
    
    .vc_custom_1459352965013 {
        margin-bottom: 0!important
    }
    
    .vc_custom_1459408424199 {
        margin-top: -22px!important;
        margin-right: 0!important;
        margin-left: 0!important;
        background-color: #00bcd4!important
    }
    
    .vc_custom_1461337788816 {
        margin-bottom: 0!important
    }
    
    .vc_custom_1459340836530 {
        margin-top: 15px!important;
        margin-right: 15px!important;
        margin-bottom: 15px!important;
        margin-left: 15px!important;
        background-color: #00bcd4!important
    }
    
    .vc_custom_1459346893117 {
        padding-right: 50px!important
    }
    
    .vc_custom_1459349481832 {
        padding-top: 80px!important
    }
    
    .vc_custom_1461676769035 {
        margin-top: 98px!important;
        margin-bottom: 0!important;
        border-bottom-width: 0!important;
        padding-left: 45px!important;
        background-color: #fff!important
    }
    
    .vc_custom_1461676786738 {
        margin-right: -1px!important;
        margin-bottom: -24px!important;
        padding-bottom: 0!important;
        padding-left: 0!important
    }
    
    .vc_custom_1459353150311 {
        padding-right: 0!important
    }
    
    .vc_custom_1459353109162 {
        margin-bottom: -23px!important;
        padding-right: 0!important
    }
    
    .vc_custom_1459353718709 {
        margin-top: 98px!important;
        padding-left: 45px!important;
        background-color: #fff!important
    }
    
    .vc_custom_1459353132681 {
        padding-right: 0!important
    }
    
    .vc_custom_1459350124038 {
        margin-bottom: -2px!important
    }
    
    .vc_custom_1459350467741 {
        margin-top: -260px!important;
        padding-right: 138px!important
    }
    
    .vc_custom_1459350540425 {
        margin-top: -260px!important;
        padding-left: 142px!important
    }
    
    .vc_custom_1459353187007 {
        padding-top: 60px!important;
        padding-bottom: 50px!important;
        padding-left: 50px!important;
        background-color: #00bcd4!important
    }
    
    .vc_custom_1459353193551 {
        padding-right: 45px!important;
        padding-left: 45px!important
    }
    
    .vc_custom_1459351169838 {
        padding-right: 30px!important;
        padding-left: 30px!important
    }
    </style>
    <noscript>&lt;style type="text/css"&gt;.wpb_animate_when_almost_visible{opacity:1}&lt;/style&gt;</noscript>
</head>

<body class="page page-id-17430 page-template-default wpb-js-composer js-comp-ver-4.12.1 vc_responsive" style="margin-right: 0px;">
    <script type="text/javascript">
    var gemSettings = {
        "isTouch": "",
        "forcedLasyDisabled": "",
        "tabletPortrait": "1",
        "tabletLandscape": "",
        "topAreaMobileDisable": "",
        "parallaxDisabled": "",
        "fillTopArea": "",
        "themePath": "http:\/\/codex-themes.com\/thegem\/wp-content\/themes\/thegem",
        "rootUrl": "http:\/\/codex-themes.com\/thegem",
        "mobileEffectsEnabled": "",
        "isRTL": ""
    };
    (function() {
        function isTouchDevice() {
            return (('ontouchstart' in window) ||
                (navigator.MaxTouchPoints > 0) ||
                (navigator.msMaxTouchPoints > 0));
        }

        window.gemSettings.isTouch = isTouchDevice();

        function userAgentDetection() {
            var ua = navigator.userAgent.toLowerCase(),
                platform = navigator.platform.toLowerCase(),
                UA = ua.match(/(opera|ie|firefox|chrome|version)[\s\/:]([\w\d\.]+)?.*?(safari|version[\s\/:]([\w\d\.]+)|$)/) || [null, 'unknown', 0],
                mode = UA[1] == 'ie' && document.documentMode;

            window.gemBrowser = {
                name: (UA[1] == 'version') ? UA[3] : UA[1],
                version: UA[2],
                platform: {
                    name: ua.match(/ip(?:ad|od|hone)/) ? 'ios' : (ua.match(/(?:webos|android)/) || platform.match(/mac|win|linux/) || ['other'])[0]
                }
            };
        }

        window.updateGemClientSize = function() {
            if (window.gemOptions == null || window.gemOptions == undefined) {
                window.gemOptions = {
                    first: false,
                    clientWidth: 0,
                    clientHeight: 0,
                    innerWidth: -1
                };
            }

            window.gemOptions.clientWidth = window.innerWidth || document.documentElement.clientWidth;
            if (document.body != null && !window.gemOptions.clientWidth) {
                window.gemOptions.clientWidth = document.body.clientWidth;
            }

            window.gemOptions.clientHeight = window.innerHeight || document.documentElement.clientHeight;
            if (document.body != null && !window.gemOptions.clientHeight) {
                window.gemOptions.clientHeight = document.body.clientHeight;
            }
        };

        window.updateGemInnerSize = function(width) {
            window.gemOptions.innerWidth = width != undefined ? width : (document.body != null ? document.body.clientWidth : 0);
        };

        userAgentDetection();
        window.updateGemClientSize(true);

        window.gemSettings.lasyDisabled = window.gemSettings.forcedLasyDisabled || (!window.gemSettings.mobileEffectsEnabled && (window.gemSettings.isTouch || window.gemOptions.clientWidth <= 800));
    })();
    (function() {
        if (window.gemBrowser.name == 'safari') {
            try {
                var safariVersion = parseInt(window.gemBrowser.version);
            } catch (e) {
                var safariVersion = 0;
            }
            if (safariVersion >= 9) {
                window.gemSettings.parallaxDisabled = true;
                window.gemSettings.fillTopArea = true;
            }
        }
    })();
    (function() {
        var fullwithData = {
            page: null,
            pageWidth: 0,
            pageOffset: {},
            fixVcRow: true,
            pagePaddingLeft: 0
        };

        function updateFullwidthData() {
            fullwithData.pageOffset = fullwithData.page.getBoundingClientRect();
            fullwithData.pageWidth = parseFloat(fullwithData.pageOffset.width);
            fullwithData.pagePaddingLeft = 0;

            if (fullwithData.page.className.indexOf('vertical-header') != -1) {
                fullwithData.pagePaddingLeft = 45;
                if (fullwithData.pageWidth >= 1600) {
                    fullwithData.pagePaddingLeft = 360;
                }
                if (fullwithData.pageWidth < 980) {
                    fullwithData.pagePaddingLeft = 0;
                }
            }
        }

        function gem_fix_fullwidth_position(element) {
            if (element == null) {
                return false;
            }

            if (fullwithData.page == null) {
                fullwithData.page = document.getElementById('page');
                updateFullwidthData();
            }

            if (fullwithData.pageWidth < 1170) {
                return false;
            }

            if (!fullwithData.fixVcRow) {
                return false;
            }

            if (element.previousElementSibling != null && element.previousElementSibling != undefined && element.previousElementSibling.className.indexOf('fullwidth-block') == -1) {
                var elementParentViewportOffset = element.previousElementSibling.getBoundingClientRect();
            } else {
                var elementParentViewportOffset = element.parentNode.getBoundingClientRect();
            }

            if (elementParentViewportOffset.top > window.gemOptions.clientHeight) {
                fullwithData.fixVcRow = false;
                return false;
            }

            if (element.className.indexOf('vc_row') != -1) {
                var elementMarginLeft = -21;
                var elementMarginRight = -21;
            } else {
                var elementMarginLeft = 0;
                var elementMarginRight = 0;
            }

            var offset = parseInt(fullwithData.pageOffset.left + 0.5) - parseInt((elementParentViewportOffset.left < 0 ? 0 : elementParentViewportOffset.left) + 0.5) - elementMarginLeft + fullwithData.pagePaddingLeft;
            var offsetKey = window.gemSettings.isRTL ? 'right' : 'left';

            element.style.position = 'relative';
            element.style[offsetKey] = offset + 'px';
            element.style.width = fullwithData.pageWidth - fullwithData.pagePaddingLeft + 'px';

            if (element.className.indexOf('vc_row') == -1) {
                element.setAttribute('data-fullwidth-updated', 1);
            }

            if (element.className.indexOf('vc_row') != -1 && !element.hasAttribute('data-vc-stretch-content')) {
                var el_full = element.parentNode.querySelector('.vc_row-full-width-before');
                var padding = -1 * offset;
                0 > padding && (padding = 0);
                var paddingRight = fullwithData.pageWidth - padding - el_full.offsetWidth + elementMarginLeft + elementMarginRight;
                0 > paddingRight && (paddingRight = 0);
                element.style.paddingLeft = padding + 'px';
                element.style.paddingRight = paddingRight + 'px';
            }
        }

        window.gem_fix_fullwidth_position = gem_fix_fullwidth_position;

        if (window.gemSettings.isTouch) {
            setTimeout(function() {
                var head = document.getElementsByTagName('head')[0],
                    link = document.createElement('link');
                link.rel = 'stylesheet';
                link.type = 'text/css';
                link.href = window.gemSettings.themePath + '/css/thegem-touch.css';
                head.appendChild(link);
            }, 1000);
        }

        if (window.gemSettings.lasyDisabled && !window.gemSettings.forcedLasyDisabled) {
            setTimeout(function() {
                var head = document.getElementsByTagName('head')[0],
                    link = document.createElement('link');
                link.rel = 'stylesheet';
                link.type = 'text/css';
                link.href = window.gemSettings.themePath + '/css/thegem-effects-disabled.css';
                head.appendChild(link);
            }, 1000);
        }

        if (window.gemSettings.parallaxDisabled) {
            var head = document.getElementsByTagName('head')[0],
                link = document.createElement('style');
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.innerHTML = ".fullwidth-block.fullwidth-block-parallax-vertical .fullwidth-block-background, .fullwidth-block.fullwidth-block-parallax-fixed .fullwidth-block-background { background-attachment: scroll !important; }";
            head.appendChild(link);
        }
    })();

    (function() {
        setTimeout(function() {
            var preloader = document.getElementById('page-preloader');
            if (preloader != null && preloader != undefined) {
                preloader.className += ' preloader-loaded';
            }
        }, window.pagePreloaderHideTime || 1000);
    })();
    </script>
    <div id="page" class="layout-fullwidth">
 
        <div id="site-header-wrapper" class=" ">
            <header id="site-header" class="site-header animated-header" role="banner"    style=" max-height: 70px;">
                <div class="container">
                    <div class="header-main logo-position-left header-layout-default header-style-3">
                    
                        <div class="site-title">
                            <div class="site-logo">
                                <a  rel="home"> <span class="logo" style="min-width: 164px;"><!--<img src=""  alt="" style="width:164px;" class="default">--><img src="images/nameicon.png" class="img-responsive"><!--<img="" alt="" style="width: 132px; margin-left: -164px; display: inline;" class="small">--> </span> </a>
                            </div>
                        </div>
                     
                    <nav id="primary-navigation" class="site-navigation primary-navigation responsive" role="navigation"style="text-align:center;">
                            <button class="menu-toggle dl-trigger">Primary Menu<span class="menu-line-1"></span><span class="menu-line-2"></span><span class="menu-line-3"></span></button>
                            <ul id="primary-menu" class="nav-menu dl-menu styled">
                                <li id="menu-item-25" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current_page_ancestor menu-item-has-children menu-item-parent menu-item-25 megamenu-first-element menu-item-current"><a href="#abt_us">Abt us</a>
                                   <!-- <ul class="sub-menu styled  dl-submenu"></ul> -->
                                </li>
                                <li id="menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-parent menu-item-24 megamenu-first-element"><a href="#whywe">Why US</a>
                                 <!--   <ul class="sub-menu styled  invert dl-submenu"></ul> -->
                                </li>
                                  <li id="menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-parent menu-item-24 megamenu-first-element"><a href="#app_link">App_link</a>
                                   <!-- <ul class="sub-menu styled  invert dl-submenu"></ul> -->
                                </li>
                                    <li id="menu-item-24" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-parent menu-item-24 megamenu-first-element"><a href="#contact">Contact Us</a>
                                 <!--   <ul class="sub-menu styled  invert dl-submenu"></ul> -->
                                </li>
                            </ul>
                        </nav>
                       
                    </div>
                </div>
            </header>
        </div>
        
               <div id="main" class="site-main">
    <div id="main-content" class="main-content">
        <div class="block-content no-bottom-margin no-top-margin">
            <div class="container-fluid">
                <div class="container-fluid responsive-image" style="padding-top: 200px;">
                    <center>
                        <h1> Why Waste Your Time on traveling </h1>
                        <h4> we are here to bring </h4>
                        <br>
                        <a href="#more">
                            <button class="w3-button w3-blue w3-round-xxlarge">Know more</button>
                        </a>
                        <a href="#main">
                            <button class="w3-button w3-blue w3-round-xxlarge">Your Order</button>
                        </a>
                    </center>
                </div>
                <div class="container-fluid jayesh" style="color:white;">
                    <center>
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <br>
                                <br>
                                <h2>Stop wasting your time</h2>
                                <h2>let us bring for you</h2>
                                <br>
                                <br>
                            </div>
                        </div>
                        <div class="row jayesh">
                            <div class="col-md-1 col-sm-1">
                            </div>
                            <div class="col-md-10 col-sm-10">
                                <div class="row">
                                    <div class="col-md-4 col-sm-4">
                                        <img src="urneed.png" height="120px" width="120px">
                                        <p>fill ur need</p>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <img src="bigcall.png" height="120px" width="120px">
                                        <p>confirm on call</p>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <img src="pickorder.png" height="120px" width="120px">
                                        <p>pick ur order</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1 col-sm-1">
                            </div>
                        </div>
                    </center>
                    <div style="height:50px;">
                    </div>
                </div>
  
                <div class="container-fluid" style="background-color:#e0e0d1;" id="whywe">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                          <br>
                                <center>
                                    <h1>WHY  US</h1>
                                </center>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="row">
                                    <div class="col-md-2 col-sm-2">
                                        <img src="orderclick.png">
                                    </div>
                                    <div class="col-md-10 col-sm-10">
                                        <h3>ORDER IN A CLICK</h3>
                                        <p style="color:navy;">You Can Order Your Desired Product
                                            <br>Just In a Click</p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-2 col-sm-2">
                                        <img src="orderclick.png">
                                    </div>
                                    <div class="col-md-10 col-sm-10">
                                        <h3>SAVE YOUR MONEY</h3>
                                        <p style="color:navy;">Why To Waste Your Money In Travelling</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="row">
                                    <div class="col-md-2 col-sm-2">
                                        <img src="orderclick.png">
                                    </div>
                                    <div class="col-md-10 col-sm-10">
                                        <h3>SAVE YOUR EFFORT</h3>
                                        <p style="color:navy;">Why To Make Effort For Searching
                                            <br>Product Here And There</p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-2 col-sm-2">
                                        <img src="orderclick.png">
                                    </div>
                                    <div class="col-md-10 col-sm-10">
                                        <h3>SAVE YOUR TIME</h3>
                                        <p style="color:navy;">Why To Invest Your Valuable Time,
                                            <br>justdeliverit Is Here</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="row">
                                    <div class="col-md-2 col-sm-2">
                                        <img src="orderclick.png">
                                    </div>
                                    <div class="col-md-10 col-sm-10">
                                        <h3>CARE FOR YOUR HEALTH</h3>
                                        <p style="color:navy;">Stay Healthy In Summer</p>
                                    </div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-md-2 col-sm-2">
                                        <img src="orderclick.png">
                                    </div>
                                    <div class="col-md-10 col-sm-10">
                                        <h3>SMART AND ECO-FRIENDLY METHOD</h3>
                                        <p style="color:navy;">We Are Promoting Digital India
                                            <br>And Reducing Pollution</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                        </ol>
                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <img src="http://dummyimage.com/1140x460/f00/fff" alt="...">
                                <div class="carousel-caption">
                                    <h1>Slider 1</h1>
                                </div>
                            </div>
                            <div class="item">
                                <img src="http://dummyimage.com/1140x460/f00/fff" alt="...">
                                <div class="carousel-caption">
                                    <h1>Slider 2</h1>
                                </div>
                            </div>
                            <div class="item">
                                <img src="http://dummyimage.com/1140x460/f00/fff" alt="...">
                                <div class="carousel-caption">
                                    <h1>Slider 2</h1>
                                </div>
                            </div>
                        </div>
                        <!-- Controls -->
                        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
                <div class="container-fluid" style="background-color:#d1e0e0;" id="main">
                    <div style="min-height: 50px;">
                    </div>
                    <div class="container">
                        <form method="POST" action="connect.php">
                            <div class="row">
                                <div class="col-md-6 space">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3" for="Name">Name:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="Name" name="name" placeholder="Enter Name">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 space">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3" for="Name">Mobile No:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="Name" name="mob" placeholder="Mobile No">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 space">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3" for="event">Hostel No:</label>
                                        <div class="col-sm-9">
                                            <select id="blood_group" name="hostel" name="hostel" class="form-control">
                                                <option value="-1">Hostel-No</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 space">
                                    <div class="form-group">
                                        <label class="control-label col-sm-3" for="Name">Room No:</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" id="Name" name="room" placeholder="Room Please">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 space">
                                    <div class="form-group">
                                        <label class="control-label col-md-2 col-sm-2" for="pr">Product Description:</label>
                                        <div class=" col-md-10 col-sm-10">
                                            <textarea class="form-control" rows="3" id="pr" name="prodis" placeholder="Product Description,Preferred Shop,Preferred Location"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-12 space">
                                    <div style="text-align: center;">
                                        <button type="submit" class="btn btn-primary btn-lg" value="sign in">Submit</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div style="min-height: 50px;">
                    </div>
                </div>
                <div class="container-fluid contactus" id="contact">
                    <br>
                    <center>
                        <h2 style="color:white;">CONTACTS US</h2>
                    </center>
                    <br>
                    <br>
                    <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-10">
                            <div class="row">
                                <div class="col-md-3 col-sm-3">
                                    <center>
                                        <img src="address.png" height="50px" width="50px" style="border-radius: 5px;">
                                        <p></p>
                                        <p>ADDRESS</p>
                                        <p>B.I.T mesra</p>
                                        <p>Hostel no -12 Room no-147</p>
                                    </center>
                                </div>
                                <div class="col-md-3 col-sm-3">
                                    <center>
                                        <img src="call.png" height="50px" width="50px" style="border-radius: 5px;">
                                        <p>PHONES</p>
                                        <p>CHANDAN: +91 8409914238</p>
                                        <p>SHASHI: +91 9060450743</p>
                                        <p>JAYESH: +91 7319730319</p>
                                    </center>
                                </div>
                                <div class="col-md-3 col-sm-3">
                                    <center>
                                        <img src="mail.png" height="50px" width="50px" style="border-radius: 5px;">
                                        <p></p>
                                        <p>CONTACTS</p>
                                        <p>justdeliverit.in@gmail.com</p>
                                    </center>
                                </div>
                                <div class="col-md-3 col-sm-3">
                                    <center>
                                        <img src="work_hrs.png" height="50px" width="50px" style="border-radius: 5px;">
                                        <p></p>
                                        <p>ADDRESS</p>
                                        <p>Monday-Friday: 9:00 - 18:00</p>
                                        <p>Saturday: 11:00 - 17:00</p>
                                        <p>Sunday: Open</p>
                                    </center>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1"></div>
                    </div>
                </div>
                <div class="container-fluid" style="background-color:#172d36;" id="more">
                    <div class="row">
                        <br>
                        <br>
                        <div class="col-md-2 col-sm-2">
                        </div>
                        <div class="col-md-8 col-sm-8">
                            <div class="row">
                                <!--<div class="col-md-4 col-sm-4">
            <p><b>Justdeliverit.in</b></p>
            <hr>
            <p style=" text-align:justify;">Justdeliverit.in is a  fast 
                                            delivery service for short 
                                            distances. till  now  this 
                                            service is in beta version.
                                            we are expanding soon.</p>      
            </div>-->
                                <div class="col-md-6 col-sm-6 col-md-offset-3 col-sm-offset-3">
                                    <p>Feed back</p>
                                    <hr>
                                    <form>
                                        <div class="form-group">
                                            <textarea class="form-control" rows="3" id="comment" placeholder="Enter Your Precious Suggestions"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control" id="mail" placeholder="Gmail">
                                        </div>
                                        <div class="col-md-12 space">
                                            <div style="text-align: center;">
                                                <button type="submit" class="btn btn-primary btn-lg" value="register">Done</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <!--    <div class="col-md-6 col-sm-6">
            <p>Recent projects</p>
            <hr>
            <center>
            <img src="merasketch.png" height="80px" width="80px">
            <img src="merasketch.png" height="80px" width="80px">
            <img src="merasketch.png" height="80px" width="80px">
            <br>
            <br>
            <img src="merasketch.png" height="80px" width="80px">
            <img src="merasketch.png" height="80px" width="80px">
            <img src="merasketch.png" height="80px" width="80px">
            </center>
            </div>
        </div> -->
                                <br>
                            </div>
                            <div class="col-md-2 col-sm-2">
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid" style="background-color:#172d36;" id="abt_us">
                        <div class="col-md-12">
                            <p>About Us</p>
                            <p style=" text-align:justify;">Justdeliverit.in is a fastest delivery service for short distances. till now this service is in beta version. we are expanding soon.</p>
                            <br>
                        </div>
                        <div class="row">
                            <div class="col-md-1 col-sm-1">
                            </div>
                            <div class="col-md-10 col-sm-10">
                                <div class="row">
                                    <div class="col-md-4 col-sm-12">
                                        <center>
                                            <div class="abtbox">
                                                <br>
                                                <img src="chandan.png">
                                                <br>
                                                <br>
                                                <p>CHANDAN KUMAR SAHU</p>
                                                <p>FOUNDER</p>
                                                <p>+91 8409914238</p>
                                                <ul class="social-network chota">
                                                    <!-- <li><a href="#" class="icoYouTube beti" title="YouTube"><i class="fa fa-youtube-play"></i></a></li>-->
                                                    <li><a href="https://plus.google.com/u/0/102611702840389818219" class="icoGoogle beti" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                                                    <li><a href="https://www.facebook.com/profile.php?id=100006627647300&fref=ts" class="icoFacebook beti" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                    <li><a href="https://twitter.com/search?q=learnmyphysics&src=typd" class="icoTwitter beti" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                    <li><a href="https://www.instagram.com/chandankumar123456789/" class="icoInstagram beti" target="_blank" title="Instagram"><i class="fa fa-instagram"></i></a></li>
                                                </ul>
                                            </div>
                                            <center>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <center>
                                            <div class="abtbox">
                                                <br>
                                                <img src="jayesh.png">
                                                <br>
                                                <br>
                                                <p>JAYESH</p>
                                                <p>Chief Technical Officer</p>
                                                <p>+91 7319730319</p>
                                                <ul class="social-network chota">
                                                    <!-- <li><a href="#" class="icoYouTube beti" title="YouTube"><i class="fa fa-youtube-play"></i></a></li>-->
                                                    <li><a href="https://plus.google.com/112982604105721344703" class="icoGoogle beti" target="_blank" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                                                    <li><a href="https://www.facebook.com/profile.php?id=100009290369362&fref=ts" target="_blank" class="icoFacebook beti" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                    <li><a href="#" class="icoTwitter beti" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                                                    <li><a href="https://www.instagram.com/jayesh_keshri_photography/" target="_blank" class="icoInstagram beti" title="Instagram"><i class="fa fa-instagram"></i></a></li>
                                                </ul>
                                            </div>
                                            <center>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <center>
                                            <div class="abtbox">
                                                <br>
                                                <img src="shashi.png">
                                                <br>
                                                <br>
                                                <p>SHASHI GUPTA</p>
                                                <p>Co-Founder &CEO</p>
                                                <p>+91 9060450743</p>
                                                <ul class="social-network chota">
                                                    <!-- <li><a href="#" class="icoYouTube beti" title="YouTube" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                                    <li><a href="https://plus.google.com/u/1/109627520032603433410" target="_blank" class="icoGoogle beti" title="Google +"><i class="fa fa-google-plus"></i></a></li>
                                                    <li><a href="https://www.facebook.com/creativeshashigupta1?fref=ts" target="_blank" class="icoFacebook beti" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                                                    <li>
                                                        <a href="https://twitter.com/creativeshashi" target="_blank" class="icoTwitter beti" title="Twitter" target="_blank"><i class=" fa fa-twitter " ></i></a></li>
                                                    <li><a href="https://www.instagram.com/yellow_crafts/ " target="_blank " class="icoInstagram beti " title="Instagram "><i class="fa fa-instagram "></i></a></li>
                                                </ul>
                                            </div>
                                    </div>
                                    </center>
                                </div>
                            </div>
                            <div class="col-md-1 col-sm-1 ">
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid " style="background-color:#002233; ">
                        <br>
                        <br>
                        <div class="row ">
                            <div class="col-md-6 " style="padding:20px 10px 10px 30px ">
                                <a>
                                    <p>&#169; 2017 Justdeliverit</p>
                                </a>
                            </div>
                            <div class="col-md-6 ">
                                <ul class="social-network social-circle " style="float:right; ">
                                    <ul class="social-network social-circle ">
                                        <li><a href="# " class="icoYouTube beti " title="YouTube "><i class="fa fa-youtube-play " target="_blank"></i></a></li>
                                        <li><a href="https://plus.google.com/u/2/112275229746620963394
 " class="icoGoogle beti " title="Google + " target="_blank"><i class="fa fa-google-plus " target="_blank"></i></a></li>
                                        <li><a href="https://www.facebook.com/justdeliverit.in/?fref=ts&ref=br_tf " class="icoFacebook beti " target="_blank" title="Facebook "><i class="fa fa-facebook "></i></a></li>
                                        <li><a href="https://twitter.com/JustdeliverI" class="icoTwitter beti " title="Twitter " target="_blank"><i class="fa fa-twitter "></i></a></li>
                                        <li><a href="https://www.instagram.com/justdeliver_it/" class="icoInstagram beti " title="Instagram " target="_blank"><i class="fa fa-instagram " target="_blank"></i></a></li>
                                        <!--  <li><a href="# " class="icoSkype beti " title="Skype "><i class="fa fa-skype "target="_blank"></i></a></li> -->
                                        <li><a href="mailto:justdeliverit.in@gmail.com" class="icoEnvelope beti " title="Justdeliver.in" target="_blank"><i class="fa fa-envelope "></i></a></li>
                                    </ul>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>                                           
  
    <script type="text/javascript">
    var recaptchaWidgets = [];
    var recaptchaCallback = function() {
        var forms = document.getElementsByTagName('form');
        var pattern = /(^|\s)g-recaptcha(\s|$)/;

        for (var i = 0; i < forms.length; i++) {
            var divs = forms[i].getElementsByTagName('div');

            for (var j = 0; j < divs.length; j++) {
                var sitekey = divs[j].getAttribute('data-sitekey');

                if (divs[j].className && divs[j].className.match(pattern) && sitekey) {
                    var params = {
                        'sitekey': sitekey,
                        'theme': divs[j].getAttribute('data-theme'),
                        'type': divs[j].getAttribute('data-type'),
                        'size': divs[j].getAttribute('data-size'),
                        'tabindex': divs[j].getAttribute('data-tabindex')
                    };

                    var callback = divs[j].getAttribute('data-callback');

                    if (callback && 'function' == typeof window[callback]) {
                        params['callback'] = window[callback];
                    }

                    var expired_callback = divs[j].getAttribute('data-expired-callback');

                    if (expired_callback && 'function' == typeof window[expired_callback]) {
                        params['expired-callback'] = window[expired_callback];
                    }

                    var widget_id = grecaptcha.render(divs[j], params);
                    recaptchaWidgets.push(widget_id);
                    break;
                }
            }
        }
    }
    </script>
    <script type="text/javascript">
    (function() {
        function addEventListener(element, event, handler) {
            if (element.addEventListener) {
                element.addEventListener(event, handler, false);
            } else if (element.attachEvent) {
                element.attachEvent('on' + event, handler);
            }
        }

        function maybePrefixUrlField() {
            if (this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
                this.value = "http://" + this.value;
            }
        }

        var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
        if (urlFields && urlFields.length > 0) {
            for (var j = 0; j < urlFields.length; j++) {
                addEventListener(urlFields[j], 'blur', maybePrefixUrlField);
            }
        } /* test if browser supports date fields */
        var testInput = document.createElement('input');
        testInput.setAttribute('type', 'date');
        if (testInput.type !== 'date') {

            /* add placeholder & pattern to all date fields */
            var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
            for (var i = 0; i < dateFields.length; i++) {
                if (!dateFields[i].placeholder) {
                    dateFields[i].placeholder = 'YYYY-MM-DD';
                }
                if (!dateFields[i].pattern) {
                    dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
                }
            }
        }

    })();
    </script>
    <link rel="stylesheet" id="icons-fontawesome-css" href="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/themes/thegem/css/icons-fontawesome.css?ver=4.6.1" type="text/css" media="all">
    <link rel="stylesheet" id="vc_tta_style-group-css" href="http://codex-themes.com/thegem/wp-content/plugins/bwp-minify/cache/fbaf67fc2355c132f9fd6f570f93c8e18978e070/minify-b1-vc_tta_style-7f88698ed8b29b68d2b15e95f94bd1d2.css" type="text/css" media="all">
    <link rel="stylesheet" id="icons-material-css" href="http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/themes/thegem/css/icons-material.css?ver=4.6.1" type="text/css" media="all">
    <script type="text/javascript">
    /* <![CDATA[ */
    var thegem_dlmenu_settings = {
        "backLabel": "Back",
        "showCurrentLabel": "Show this page"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var _wpcf7 = {
        "loaderUrl": "http:\/\/codex-themes.com\/thegem\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif",
        "recaptcha": {
            "messages": {
                "empty": "Please verify that you are not a robot."
            }
        },
        "sending": "Sending ...",
        "cached": "1"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var woocommerce_params = {
        "ajax_url": "\/thegem\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/thegem\/real-estate\/?wc-ajax=%%endpoint%%"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var wc_cart_fragments_params = {
        "ajax_url": "\/thegem\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/thegem\/real-estate\/?wc-ajax=%%endpoint%%",
        "fragment_name": "wc_fragments"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var yith_wcwl_l10n = {
        "ajax_url": "\/thegem\/wp-admin\/admin-ajax.php",
        "redirect_to_cart": "no",
        "multi_wishlist": "",
        "hide_add_button": "1",
        "is_user_logged_in": "",
        "ajax_loader_url": "http:\/\/codex-themes.com\/thegem\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif",
        "remove_from_wishlist_after_add_to_cart": "yes",
        "labels": {
            "cookie_disabled": "We are sorry, but this feature is available only if cookies are enabled on your browser.",
            "added_to_cart_message": "<div class=\"woocommerce-message\">Product correctly added to cart<\/div>"
        },
        "actions": {
            "add_to_wishlist_action": "add_to_wishlist",
            "remove_from_wishlist_action": "remove_from_wishlist",
            "move_to_another_wishlist_action": "move_to_another_wishlsit",
            "reload_wishlist_and_adding_elem_action": "reload_wishlist_and_adding_elem"
        }
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var zilla_likes = {
        "ajaxurl": "http:\/\/codex-themes.com\/thegem\/wp-admin\/admin-ajax.php"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var wc_add_to_cart_params = {
        "ajax_url": "\/thegem\/wp-admin\/admin-ajax.php",
        "wc_ajax_url": "\/thegem\/real-estate\/?wc-ajax=%%endpoint%%",
        "i18n_view_cart": "View Cart",
        "cart_url": "http:\/\/codex-themes.com\/thegem\/cart\/",
        "is_cart": "",
        "cart_redirect_after_add": "no"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var portfolio_ajax_4cc8f9e = {
        "data": {
            "portfolio": "real-estate-splash",
            "title": "",
            "layout": "1x",
            "layout_version": "fullwidth",
            "caption_position": "zigzag",
            "style": "justified",
            "gaps_size": "42",
            "display_titles": "page",
            "background_style": "white",
            "hover": "default",
            "pagination": "normal",
            "loading_animation": "move-up",
            "items_per_page": 8,
            "with_filter": "",
            "show_info": "1",
            "is_ajax": false,
            "disable_socials": "",
            "fullwidth_columns": "4",
            "likes": "1",
            "sorting": false,
            "orderby": "",
            "order": "",
            "button": {
                "text": "Load More",
                "style": "flat",
                "size": "medium",
                "text_weight": "normal",
                "no_uppercase": 0,
                "corner": 25,
                "border": 2,
                "text_color": "",
                "background_color": "#00bcd5",
                "border_color": "",
                "hover_text_color": "",
                "hover_background_color": "",
                "hover_border_color": "",
                "icon_pack": "elegant",
                "icon_elegant": "",
                "icon_material": "",
                "icon_fontawesome": "",
                "icon_userpack": "",
                "icon_position": "left",
                "separator": "load-more",
                "icon": ""
            },
            "metro_max_row_height": "380"
        },
        "url": "http:\/\/codex-themes.com\/thegem\/wp-admin\/admin-ajax.php",
        "nonce": "96428577a0"
    };
    /* ]]> */
    </script>
    <script type="text/javascript">
    window.customMegaMenuSettings = [{
        menuItem: 21,
        urls: [/^\/thegem\/(shop|product\-category|cart|checkout|my\-account)\/.*$/],
        data: {
            backgroundImage: 'url(http://thegem2.codexthemes.netdna-cdn.com/thegem/wp-content/uploads/2016/03/2-27.jpg)',
            backgroundPosition: 'right top',
            style: 'grid',
            masonry: true,
            padding: '0px 581px 0px 0px',
            borderRight: '0'
        }
    }];

    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-45465556-11', 'auto');
    ga('send', 'pageview');
    </script>
    <script type="text/javascript" defer="defer" src="http://codex-themes.com/thegem/wp-content/plugins/bwp-minify/cache/fbaf67fc2355c132f9fd6f570f93c8e18978e070/minify-b1-jquery-core-0bb52fc78dabc7354e7fe63067a3bfc1.js"></script>
    <script type="text/javascript">
    /* <![CDATA[ */
    var mc4wp_forms_config = [];
    /* ]]> */
    </script>
    <script type="text/javascript" defer="defer" src="http://codex-themes.com/thegem/wp-content/plugins/bwp-minify/cache/fbaf67fc2355c132f9fd6f570f93c8e18978e070/minify-b1-jquery-carouFredSel-ea66a4d2f23c8d77769e1f071536729e.js"></script>
    <script type="text/javascript" defer="defer" async="async" src="https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&amp;render=explicit&amp;ver=2.0"></script>
     
</body>

</html>
